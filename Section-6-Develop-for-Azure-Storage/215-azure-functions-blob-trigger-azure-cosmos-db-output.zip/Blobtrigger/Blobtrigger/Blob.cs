﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Blobtrigger
{
    class Blob
    {
        public string blobid { get; set; }

        public string blobname { get; set; }
        public long blobsize { get; set; }

    }
}
