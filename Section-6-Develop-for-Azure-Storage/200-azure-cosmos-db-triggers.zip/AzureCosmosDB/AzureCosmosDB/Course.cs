﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AzureCosmosDB
{
    class Course
    {
        public string id { get; set; }        
        public string coursename { get; set; }
        public decimal rating { get; set; }
    }
}
