﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CosmosDB
{
    class Order
    {
        public string orderid { get; set; }
        public int price { get; set; }
    }
}
