﻿using System;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.UI;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using sqlappinsights.Data;

[assembly: HostingStartup(typeof(sqlappinsights.Areas.Identity.IdentityHostingStartup))]
namespace sqlappinsights.Areas.Identity
{
    public class IdentityHostingStartup : IHostingStartup
    {
        public void Configure(IWebHostBuilder builder)
        {
            builder.ConfigureServices((context, services) => {
                services.AddDbContext<sqlappinsightsContext>(options =>
                    options.UseSqlite(
                        context.Configuration.GetConnectionString("sqlappinsightsContextConnection")));

                services.AddDefaultIdentity<IdentityUser>(options => options.SignIn.RequireConfirmedAccount = true)
                    .AddEntityFrameworkStores<sqlappinsightsContext>();
            });
        }
    }
}